// Wait for the DOM and WordPress editor scripts to be ready
document.addEventListener('DOMContentLoaded', function () {
    const analyzeButton = document.getElementById('ai-seo-analyze-button');
    const resultsDiv = document.getElementById('ai-seo-results');
    const statusP = document.getElementById('ai-seo-status');
    const scoreDiv = document.getElementById('ai-seo-score');
    const issuesUl = document.getElementById('ai-seo-issues');
    const suggestionsUl = document.getElementById('ai-seo-suggestions');
    const keywordsDiv = document.getElementById('ai-seo-keywords');

    if (!analyzeButton) {
        console.error('AI SEO Analyze button not found!');
        return;
    }

    analyzeButton.addEventListener('click', function () {
        // --- Get content from WordPress Editor ---
        let postContent = '';
        let postTitle = '';

        try {
            // Try getting content from the Block Editor (Gutenberg)
            if (wp && wp.data && wp.data.select('core/editor')) {
                postContent = wp.data.select('core/editor').getEditedPostContent();
                postTitle = wp.data.select('core/editor').getEditedPostAttribute('title');
                console.log('Using Block Editor data');
            } else if (typeof tinymce !== 'undefined' && tinymce.get('content')) {
                // Fallback for Classic Editor (if TinyMCE is active)
                postContent = tinymce.get('content').getContent();
                postTitle = document.getElementById('title') ? document.getElementById('title').value : '';
                console.log('Using Classic Editor data');
            } else {
                 console.error('Could not get editor content.');
                 statusP.textContent = 'Error: Could not access editor content.';
                 return;
            }
        } catch (e) {
             console.error('Error getting editor content:', e);
             statusP.textContent = 'Error accessing editor data.';
             return;
        }


        if (!postContent.trim()) {
            statusP.textContent = 'Error: Content is empty.';
            return;
        }

        // --- Prepare for API Call ---
        statusP.textContent = 'Analyzing...';
        scoreDiv.innerHTML = '';
        issuesUl.innerHTML = '';
        suggestionsUl.innerHTML = '';
        keywordsDiv.innerHTML = '';
        analyzeButton.disabled = true;

        const apiEndpoint = aiSeoData.apiUrl; // Get URL from wp_localize_script
        const requestBody = {
            content: postContent,
            contentType: 'html', // WordPress content is HTML
            config: {} // Add targetKeyword here if you implement an input field
        };

        // --- Make API Call ---
        fetch(apiEndpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                // 'X-WP-Plugin-Key': aiSeoData.apiKey // Add this line if using static API key
            },
            body: JSON.stringify(requestBody),
        })
        .then(response => {
            if (!response.ok) {
                // Try to get error message from API response body
                return response.json().then(errData => {
                     throw new Error(`API Error ${response.status}: ${errData.message || errData.detail || response.statusText}`);
                }).catch(() => {
                    // Fallback if response body isn't JSON or has no message
                     throw new Error(`API Error ${response.status}: ${response.statusText}`);
                });
            }
            return response.json();
        })
        .then(data => {
            // --- Display Results ---
            statusP.textContent = 'Analysis Complete!';
            scoreDiv.textContent = `SEO Score: ${data.seoScore ?? 'N/A'}`;

            // Issues
            if (data.issues && data.issues.length > 0) {
                data.issues.forEach(issue => {
                    const li = document.createElement('li');
                    li.textContent = `[${issue.type}] ${issue.message}`;
                    issuesUl.appendChild(li);
                });
            } else {
                issuesUl.innerHTML = '<li>No issues found.</li>';
            }

            // Suggestions
            if (data.suggestions && data.suggestions.length > 0) {
                data.suggestions.forEach(suggestion => {
                    const li = document.createElement('li');
                     li.innerHTML = `[${suggestion.type}] ${suggestion.message}<br/><em>${suggestion.content}</em>`;
                     if (suggestion.context) {
                         li.innerHTML += `<br/><small>Context: ${suggestion.context}</small>`;
                     }
                    suggestionsUl.appendChild(li);
                });
            } else {
                suggestionsUl.innerHTML = '<li>No AI suggestions.</li>';
            }

            // Keyword Analysis (Optional)
             if (data.keywordAnalysis) {
                 const ka = data.keywordAnalysis;
                 keywordsDiv.innerHTML = `
                     <h4>Keyword: "${ka.targetKeyword}"</h4>
                     <ul>
                         <li>In Title: ${ka.foundInTitle}</li>
                         <li>In Meta: ${ka.foundInMeta}</li>
                         <li>In H1: ${ka.foundInH1}</li>
                         <li>Count: ${ka.bodyCount}</li>
                         <li>Density: ${ka.density}%</li>
                     </ul>`;
             } else {
                keywordsDiv.innerHTML = '';
             }

        })
        .catch(error => {
            console.error('Error calling AI SEO API:', error);
            statusP.textContent = `Error: ${error.message}`;
            scoreDiv.innerHTML = '';
            issuesUl.innerHTML = '';
            suggestionsUl.innerHTML = '';
            keywordsDiv.innerHTML = '';
        })
        .finally(() => {
            analyzeButton.disabled = false; // Re-enable button
        });
    });
});