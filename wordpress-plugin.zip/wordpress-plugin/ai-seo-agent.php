<?php
/**
 * Plugin Name: AI SEO Agent
 * Description: Analyzes post content using the AI SEO Agent API.
 * Version: 0.1
 * Author: Your Name
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// 1. Add the Meta Box to Post Edit Screens
function ai_seo_register_meta_box() {
    add_meta_box(
        'ai_seo_agent_metabox',           // Unique ID for the meta box
        'AI SEO Analysis',                // Title shown in the meta box header
        'ai_seo_render_meta_box_content', // Callback function to render the HTML
        ['post', 'page'],                 // Show on Posts and Pages (add custom post types if needed)
        'side',                           // Context (normal, side, advanced)
        'high'                            // Priority
    );
}
add_action( 'add_meta_boxes', 'ai_seo_register_meta_box' );

// 2. Render the HTML content of the Meta Box
function ai_seo_render_meta_box_content( $post ) {
    // Basic HTML structure
    ?>
    <div id="ai-seo-controls">
        <button type="button" id="ai-seo-analyze-button" class="button">Analyze SEO</button>
    </div>
    <hr>
    <div id="ai-seo-results">
        <p id="ai-seo-status">Ready.</p>
        <div id="ai-seo-score"></div>
        <h4>Issues:</h4>
        <ul id="ai-seo-issues"></ul>
        <h4>Suggestions:</h4>
        <ul id="ai-seo-suggestions"></ul>
        <div id="ai-seo-keywords"></div>
    </div>
    <?php
    // Add a nonce field if you plan to use WordPress AJAX later (good practice)
    // wp_nonce_field( 'ai_seo_analyze_action', 'ai_seo_nonce' );
}

// 3. Enqueue JavaScript and CSS for the admin editor screen
function ai_seo_enqueue_scripts( $hook ) {
    // Only load on post edit screens (post.php and post-new.php)
    if ( 'post.php' != $hook && 'post-new.php' != $hook ) {
        return;
    }

    // Enqueue the JavaScript file
    wp_enqueue_script(
        'ai-seo-script', // Handle
        plugin_dir_url( __FILE__ ) . 'admin/js/ai-seo-script.js', // Path to file
        array( 'wp-data', 'wp-editor', 'wp-element', 'wp-components', 'jquery' ), // Dependencies (wp-data is important for Gutenberg)
        '1.0', // Version
        true // Load in footer
    );

     // Pass the API URL to the script (REPLACE with your actual API endpoint if different)
    wp_localize_script( 'ai-seo-script', 'aiSeoData', array(
        'apiUrl' => 'http://localhost:4000/api/seo/analyze',
        // 'apiKey' => 'YOUR_STATIC_API_KEY' // Add this if you used the API key method
    ));


    // Enqueue the CSS file (optional)
    // wp_enqueue_style(
    //     'ai-seo-styles',
    //     plugin_dir_url( __FILE__ ) . 'admin/css/ai-seo-styles.css',
    //     array(),
    //     '1.0'
    // );
}
add_action( 'admin_enqueue_scripts', 'ai_seo_enqueue_scripts' );

?>