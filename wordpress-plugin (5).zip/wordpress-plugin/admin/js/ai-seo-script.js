document.addEventListener('DOMContentLoaded', function () {
    // --- Get DOM Elements ---
    const analyzeButton = document.getElementById('ai-seo-analyze-button');
    const resultsDiv = document.getElementById('ai-seo-results');
    const statusP = document.getElementById('ai-seo-status');
    const scoreDiv = document.getElementById('ai-seo-score');
    const issuesContainer = document.getElementById('ai-seo-issues-container');
    const issuesUl = document.getElementById('ai-seo-issues');
    const suggestionsContainer = document.getElementById('ai-seo-suggestions-container');
    const suggestionsUl = document.getElementById('ai-seo-suggestions');
    const keywordsContainer = document.getElementById('ai-seo-keywords');
    const keywordsDetailsDiv = document.getElementById('ai-seo-keyword-details');
    const keywordInput = document.getElementById('ai-seo-target-keyword');

    // --- Helper function to create Apply Button ---
    function createApplyButton(suggestionText, type, context = null) {
        const button = document.createElement('button');
        button.textContent = 'Apply';
        button.type = 'button'; // Prevent form submission
        button.className = 'button button-small ai-seo-apply-button'; // Add specific class
        button.style.marginLeft = '10px';
        button.style.verticalAlign = 'middle';

        // Add data attributes to store suggestion details
        button.dataset.suggestionText = suggestionText;
        button.dataset.suggestionType = type;
        if (context) {
             button.dataset.suggestionContext = context;
        }

        button.addEventListener('click', handleApplySuggestion);
        return button;
    }

    // --- Function to handle Apply Button Clicks ---
// --- Function to handle Apply Button Clicks ---
function handleApplySuggestion(event) {
    const button = event.target;
    const textToApply = button.dataset.suggestionText;
    const type = button.dataset.suggestionType;
    const context = button.dataset.suggestionContext; // e.g., image src
    const currentStatusP = document.getElementById('ai-seo-status');

    console.log("Apply clicked!", { type, textToApply, context });
    if (currentStatusP) currentStatusP.textContent = 'Applying suggestion...';
    button.disabled = true;

    try {
        // --- Logic for Meta Description ---
        if (type === 'ai_meta') {
            // *** CHANGE THE META KEY HERE ***
            const metaKey = '_ai_seo_meta_description'; // Use your custom hidden key
            console.log(`Attempting to apply meta description using custom key: ${metaKey}`);

            if (wp && wp.data && wp.data.dispatch('core/editor')) {
                try {
                    // This saves the data to WordPress's post meta table
                    wp.data.dispatch('core/editor').editPost({ meta: { [metaKey]: textToApply } });
                    console.log('editPost dispatch called successfully for custom meta.');
                    if (currentStatusP) currentStatusP.textContent = 'Meta description saved (as custom field).';
                    button.textContent = 'Applied!';
                    setTimeout(() => { button.textContent = 'Apply'; }, 2000);
                } catch (dispatchError) {
                    console.error('Error occurred during editPost dispatch:', dispatchError);
                    throw new Error(`WordPress API Error: ${dispatchError.message || 'Could not update meta'}`);
                }
            } else {
                throw new Error('WordPress Block Editor API (wp.data) not available.');
            }
        }
        // --- Logic for Alt Text (remains the same as before) ---
        else if (type === 'ai_alt_text' && context) {
            // ... (Keep the alt text logic from the previous version) ...
             if (wp && wp.data && wp.data.select('core/editor') && wp.data.dispatch('core/editor') && wp.blocks && wp.blocks.createBlock && wp.blocks.cloneBlock) {
                    // **More Robust Block Editor Method**
                    const currentBlocks = wp.data.select('core/editor').getBlocks();
                    let blockUpdated = false;

                    function findAndUpdateImageBlock(blocks) {
                        const updatedBlocks = blocks.map(block => {
                            if (blockUpdated) return block;
                            if (block.name === 'core/image' && block.attributes.url === context) {
                                console.log('Found matching image block:', block);
                                const newAttributes = { ...block.attributes, alt: textToApply };
                                const updatedBlock = wp.blocks.createBlock(block.name, newAttributes, block.innerBlocks);
                                blockUpdated = true;
                                return updatedBlock;
                            }
                            if (block.innerBlocks && block.innerBlocks.length > 0) {
                                const newInnerBlocks = findAndUpdateImageBlock(block.innerBlocks);
                                if (newInnerBlocks !== block.innerBlocks) {
                                     return wp.blocks.cloneBlock(block, {}, newInnerBlocks);
                                }
                            }
                            return block;
                        });
                        return updatedBlocks;
                    }

                    const newBlocks = findAndUpdateImageBlock(currentBlocks);

                    if (blockUpdated) {
                        wp.data.dispatch('core/editor').resetEditorBlocks(newBlocks);
                        if (currentStatusP) currentStatusP.textContent = 'Alt text applied to image block.';
                         button.textContent = 'Applied!';
                         setTimeout(() => { button.textContent = 'Apply'; }, 2000);
                    } else {
                         console.warn('Could not find matching core/image block for src:', context);
                          if (currentStatusP) currentStatusP.textContent = 'Could not find image block to apply alt text.';
                         button.disabled = false;
                    }

                } else {
                    throw new Error("Block Editor APIs (wp.data, wp.blocks) not fully available for alt text update.");
                }
        }
         else {
             if (currentStatusP) currentStatusP.textContent = 'Unknown suggestion type or missing context.';
             button.disabled = false;
        }

    } catch (e) {
         console.error("Error applying suggestion:", e);
         if (currentStatusP) currentStatusP.textContent = `Error applying: ${e.message}`;
         button.disabled = false;
    } finally {
         if (button.disabled && button.textContent !== 'Applied!') {
             setTimeout(() => { button.disabled = false; }, 1000);
         }
    }
}

// --- Rest of the file (including analyzeButton listener, createApplyButton, fetch call) remains the same ---
// ...

    // --- Analyze Button Event Listener ---
    if (!analyzeButton) {
        console.error('AI SEO Analyze button not found!');
        return;
    }

    analyzeButton.addEventListener('click', function () {
        let postContent = '';
        let postTitle = '';
        const targetKeyword = keywordInput ? keywordInput.value.trim() : '';

        try {
            if (wp && wp.data && wp.data.select('core/editor')) {
                postContent = wp.data.select('core/editor').getEditedPostContent();
                postTitle = wp.data.select('core/editor').getEditedPostAttribute('title');
                console.log('Using Block Editor data');
            } else if (typeof tinymce !== 'undefined' && tinymce.get('content')) {
                postContent = tinymce.get('content').getContent();
                postTitle = document.getElementById('title') ? document.getElementById('title').value : '';
                console.log('Using Classic Editor data');
            } else {
                 console.error('Could not get editor content.');
                 statusP.textContent = 'Error: Could not access editor content.';
                 return;
            }
        } catch (e) {
             console.error('Error getting editor content:', e);
             statusP.textContent = 'Error accessing editor data.';
             return;
        }

        if (!postContent.trim()) {
            statusP.textContent = 'Error: Content is empty.';
            return;
        }

        // --- Reset UI before API Call ---
        statusP.textContent = 'Analyzing...';
        scoreDiv.innerHTML = '';
        issuesUl.innerHTML = '';
        suggestionsUl.innerHTML = '';
        keywordsDetailsDiv.innerHTML = '';
        issuesContainer.style.display = 'none';
        suggestionsContainer.style.display = 'none';
        keywordsContainer.style.display = 'none';
        analyzeButton.disabled = true;

        const apiEndpoint = aiSeoData.apiUrl;
        const requestBody = {
            content: postContent,
            contentType: 'html',
            config: {}
        };
        if (targetKeyword) {
            requestBody.config.targetKeyword = targetKeyword;
        }

        // --- Fetch API Call ---
        fetch(apiEndpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                // Add Auth headers here if/when needed
            },
            body: JSON.stringify(requestBody),
        })
        .then(response => {
            if (!response.ok) {
                return response.json().then(errData => {
                     throw new Error(`API Error ${response.status}: ${errData.message || errData.detail || response.statusText}`);
                }).catch(() => {
                    throw new Error(`API Error ${response.status}: ${response.statusText}`);
                });
            }
            return response.json();
        })
        .then(data => {
            // --- Display Results ---
            statusP.textContent = 'Analysis Complete!';
            scoreDiv.textContent = `SEO Score: ${data.seoScore ?? 'N/A'}`;

            // Issues
            issuesUl.innerHTML = ''; // Clear previous
            if (data.issues && data.issues.length > 0) {
                 data.issues.forEach(issue => {
                    const li = document.createElement('li');
                    li.classList.add(`issue-${issue.type}`);
                    li.textContent = `${issue.message}`;
                    issuesUl.appendChild(li);
                });
                 issuesContainer.style.display = 'block';
            } else {
                 issuesUl.innerHTML = '<li>No issues found.</li>';
                 issuesContainer.style.display = 'block';
            }

            // Suggestions
           // Inside the .then(data => { ... }) block where suggestions are processed

            // Suggestions - Display using list items, explanation, and Apply buttons
            suggestionsUl.innerHTML = ''; // Clear previous
            if (data.suggestions && data.suggestions.length > 0) {
                 data.suggestions.forEach(suggestion => {
                    const li = document.createElement('li');
                    li.classList.add('ai-seo-suggestion-item'); // Add class for styling

                    // Container for suggestion text and explanation
                    const suggestionDiv = document.createElement('div');
                    suggestionDiv.classList.add('suggestion-content');

                    // Suggestion Text (the actual content to apply)
                    const suggestionText = document.createElement('code'); // Use <code> for suggestion?
                    suggestionText.textContent = suggestion.content;
                    suggestionDiv.appendChild(suggestionText);

                    // Explanation Text (if available)
                    if (suggestion.explanation) {
                        const explanationP = document.createElement('p');
                        explanationP.classList.add('suggestion-explanation');
                        explanationP.textContent = suggestion.explanation;
                        suggestionDiv.appendChild(explanationP);
                    }

                    // Context (if available, e.g., image src)
                    if (suggestion.context) {
                         const contextSmall = document.createElement('small');
                         contextSmall.classList.add('suggestion-context');
                         contextSmall.textContent = `Context: ${suggestion.context.substring(0, 70)}...`;
                         suggestionDiv.appendChild(contextSmall);
                     }

                    li.appendChild(suggestionDiv); // Add content div to list item

                     // Add Apply button for relevant types
                     if (suggestion.type === 'ai_meta' || suggestion.type === 'ai_alt_text') {
                         const applyButton = createApplyButton(suggestion.content, suggestion.type, suggestion.context);
                         li.appendChild(applyButton); // Append button next to the content div
                     }
                    suggestionsUl.appendChild(li);
                });
                 suggestionsContainer.style.display = 'block';
            } else {
                 suggestionsUl.innerHTML = '<li>No AI suggestions.</li>';
                 suggestionsContainer.style.display = 'block'; // Show even if empty
            }

            
            // Keyword Analysis
             keywordsDetailsDiv.innerHTML = ''; // Clear previous
             if (data.keywordAnalysis) {
                 const ka = data.keywordAnalysis;
                 keywordsDetailsDiv.innerHTML = `
                     <p><strong>Target: "${ka.targetKeyword}"</strong></p>
                     <ul style="list-style: none; padding-left: 0; margin-left: 0;">
                         <li>In Title: ${ka.foundInTitle ? '✅ Yes' : '❌ No'}</li>
                         <li>In Meta Desc: ${ka.foundInMeta ? '✅ Yes' : '❌ No'}</li>
                         <li>In H1: ${ka.foundInH1 ? '✅ Yes' : '❌ No'}</li>
                         <li>Body Count: ${ka.bodyCount}</li>
                         <li>Density: ${ka.density}%</li>
                     </ul>`;
                  keywordsContainer.style.display = 'block';
             } else {
                keywordsDetailsDiv.innerHTML = targetKeyword ? '<p>Keyword analysis not available.</p>' : '';
                keywordsContainer.style.display = targetKeyword ? 'block' : 'none';
             }

        })
        .catch(error => {
            console.error('Error calling AI SEO API:', error);
            statusP.textContent = `Error: ${error.message}`;
            // Clear results on error
            scoreDiv.innerHTML = '';
            issuesUl.innerHTML = '';
            suggestionsUl.innerHTML = '';
            keywordsDetailsDiv.innerHTML = '';
            issuesContainer.style.display = 'none';
            suggestionsContainer.style.display = 'none';
            keywordsContainer.style.display = 'none';
        })
        .finally(() => {
            analyzeButton.disabled = false;
        });
    });

    console.log("AI SEO Script Initialized"); // Add confirmation
});