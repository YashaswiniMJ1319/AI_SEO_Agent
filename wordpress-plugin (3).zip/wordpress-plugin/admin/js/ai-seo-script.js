document.addEventListener('DOMContentLoaded', function () {
    // --- Get DOM Elements ---
    const analyzeButton = document.getElementById('ai-seo-analyze-button');
    const resultsDiv = document.getElementById('ai-seo-results');
    const statusP = document.getElementById('ai-seo-status');
    const scoreDiv = document.getElementById('ai-seo-score');
    const issuesContainer = document.getElementById('ai-seo-issues-container');
    const issuesUl = document.getElementById('ai-seo-issues');
    const suggestionsContainer = document.getElementById('ai-seo-suggestions-container');
    const suggestionsUl = document.getElementById('ai-seo-suggestions');
    const keywordsContainer = document.getElementById('ai-seo-keywords');
    const keywordsDetailsDiv = document.getElementById('ai-seo-keyword-details');
    const keywordInput = document.getElementById('ai-seo-target-keyword');

    // --- Helper function to create Apply Button ---
    function createApplyButton(suggestionText, type, context = null) {
        const button = document.createElement('button');
        button.textContent = 'Apply';
        button.type = 'button'; // Prevent form submission
        button.className = 'button button-small ai-seo-apply-button'; // Add specific class
        button.style.marginLeft = '10px';
        button.style.verticalAlign = 'middle';

        // Add data attributes to store suggestion details
        button.dataset.suggestionText = suggestionText;
        button.dataset.suggestionType = type;
        if (context) {
             button.dataset.suggestionContext = context;
        }

        button.addEventListener('click', handleApplySuggestion);
        return button;
    }

    // --- Function to handle Apply Button Clicks ---
    function handleApplySuggestion(event) {
        const button = event.target;
        const textToApply = button.dataset.suggestionText;
        const type = button.dataset.suggestionType;
        const context = button.dataset.suggestionContext; // e.g., image src
        // Get statusP again inside the handler in case it wasn't ready globally initially
        const currentStatusP = document.getElementById('ai-seo-status');

        console.log("Apply clicked!", { type, textToApply, context });
        if (currentStatusP) currentStatusP.textContent = 'Applying suggestion...';
        button.disabled = true; // Disable button while applying

        try {
            // --- Logic for Meta Description ---
            if (type === 'ai_meta') {
                // IMPORTANT: These meta keys are EXAMPLES.
                // You MUST verify the correct key used by the target SEO plugin (Yoast, Rank Math, etc.)
                // Common keys: '_yoast_wpseo_metadesc', 'rank_math_description'
                // This also assumes the SEO plugin registers its meta field for REST API updates.
                const potentialMetaKeys = ['_yoast_wpseo_metadesc', 'rank_math_description'];
                let metaKeyToUse = potentialMetaKeys[0]; // Default or add logic to detect active plugin

                // Add simple detection logic (example - needs refinement)
                // if (document.getElementById('rank-math-metabox')) {
                //     metaKeyToUse = 'rank_math_description';
                // }

                console.log(`Attempting to apply meta description using key: ${metaKeyToUse}`);

                if (wp && wp.data && wp.data.dispatch('core/editor')) {
                    wp.data.dispatch('core/editor').editPost({ meta: { [metaKeyToUse]: textToApply } });
                     if (currentStatusP) currentStatusP.textContent = 'Meta description applied (Save post to confirm in SEO plugin).';
                    // Optionally visually indicate success
                    button.textContent = 'Applied!';
                    setTimeout(() => { button.textContent = 'Apply'; }, 2000);
                } else {
                    throw new Error('WordPress Block Editor API (wp.data) not available.');
                }
            }

            // --- Logic for Alt Text ---
            else if (type === 'ai_alt_text' && context) {
                 if (wp && wp.data && wp.data.select('core/editor') && wp.data.dispatch('core/editor') && wp.blocks && wp.blocks.createBlock && wp.blocks.cloneBlock) {
                    // **More Robust Block Editor Method**
                    const currentBlocks = wp.data.select('core/editor').getBlocks();
                    let blockUpdated = false;

                    // Recursive function to find and update image blocks
                    function findAndUpdateImageBlock(blocks) {
                        const updatedBlocks = blocks.map(block => {
                            if (blockUpdated) return block; // Stop if already updated

                            // Check direct block match
                            if (block.name === 'core/image' && block.attributes.url === context) {
                                console.log('Found matching image block:', block);
                                const newAttributes = { ...block.attributes, alt: textToApply };
                                const updatedBlock = wp.blocks.createBlock(block.name, newAttributes, block.innerBlocks);
                                blockUpdated = true;
                                return updatedBlock;
                            }

                            // Check within inner blocks
                            if (block.innerBlocks && block.innerBlocks.length > 0) {
                                const newInnerBlocks = findAndUpdateImageBlock(block.innerBlocks);
                                // If inner blocks changed, we need to create a new instance of the parent block
                                if (newInnerBlocks !== block.innerBlocks) {
                                     // Use cloneBlock to preserve parent attributes
                                     return wp.blocks.cloneBlock(block, {}, newInnerBlocks);
                                }
                            }
                            return block; // Return unchanged block
                        });
                        return updatedBlocks;
                    }

                    const newBlocks = findAndUpdateImageBlock(currentBlocks);

                    if (blockUpdated) {
                        wp.data.dispatch('core/editor').resetEditorBlocks(newBlocks);
                        if (currentStatusP) currentStatusP.textContent = 'Alt text applied to image block.';
                         button.textContent = 'Applied!';
                         setTimeout(() => { button.textContent = 'Apply'; }, 2000);
                    } else {
                         console.warn('Could not find matching core/image block for src:', context);
                          if (currentStatusP) currentStatusP.textContent = 'Could not find image block to apply alt text.';
                         button.disabled = false; // Re-enable if block not found
                    }

                } else {
                    throw new Error("Block Editor APIs (wp.data, wp.blocks) not fully available for alt text update.");
                    // String replacement fallback is too unreliable, better to show an error.
                    // applyAltTextViaStringReplace(context, textToApply, currentStatusP);
                }
            }
            else {
                 if (currentStatusP) currentStatusP.textContent = 'Unknown suggestion type or missing context.';
                 button.disabled = false;
            }

        } catch (e) {
             console.error("Error applying suggestion:", e);
             if (currentStatusP) currentStatusP.textContent = `Error applying: ${e.message}`;
             button.disabled = false; // Re-enable button on error
        } finally {
             // Re-enable button after a short delay if it wasn't already re-enabled by an error
             if (button.disabled && button.textContent !== 'Applied!') {
                 setTimeout(() => { button.disabled = false; }, 1000);
             }
        }
    }

    // --- Analyze Button Event Listener ---
    if (!analyzeButton) {
        console.error('AI SEO Analyze button not found!');
        return;
    }

    analyzeButton.addEventListener('click', function () {
        let postContent = '';
        let postTitle = '';
        const targetKeyword = keywordInput ? keywordInput.value.trim() : '';

        try {
            if (wp && wp.data && wp.data.select('core/editor')) {
                postContent = wp.data.select('core/editor').getEditedPostContent();
                postTitle = wp.data.select('core/editor').getEditedPostAttribute('title');
                console.log('Using Block Editor data');
            } else if (typeof tinymce !== 'undefined' && tinymce.get('content')) {
                postContent = tinymce.get('content').getContent();
                postTitle = document.getElementById('title') ? document.getElementById('title').value : '';
                console.log('Using Classic Editor data');
            } else {
                 console.error('Could not get editor content.');
                 statusP.textContent = 'Error: Could not access editor content.';
                 return;
            }
        } catch (e) {
             console.error('Error getting editor content:', e);
             statusP.textContent = 'Error accessing editor data.';
             return;
        }

        if (!postContent.trim()) {
            statusP.textContent = 'Error: Content is empty.';
            return;
        }

        // --- Reset UI before API Call ---
        statusP.textContent = 'Analyzing...';
        scoreDiv.innerHTML = '';
        issuesUl.innerHTML = '';
        suggestionsUl.innerHTML = '';
        keywordsDetailsDiv.innerHTML = '';
        issuesContainer.style.display = 'none';
        suggestionsContainer.style.display = 'none';
        keywordsContainer.style.display = 'none';
        analyzeButton.disabled = true;

        const apiEndpoint = aiSeoData.apiUrl;
        const requestBody = {
            content: postContent,
            contentType: 'html',
            config: {}
        };
        if (targetKeyword) {
            requestBody.config.targetKeyword = targetKeyword;
        }

        // --- Fetch API Call ---
        fetch(apiEndpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                // Add Auth headers here if/when needed
            },
            body: JSON.stringify(requestBody),
        })
        .then(response => {
            if (!response.ok) {
                return response.json().then(errData => {
                     throw new Error(`API Error ${response.status}: ${errData.message || errData.detail || response.statusText}`);
                }).catch(() => {
                    throw new Error(`API Error ${response.status}: ${response.statusText}`);
                });
            }
            return response.json();
        })
        .then(data => {
            // --- Display Results ---
            statusP.textContent = 'Analysis Complete!';
            scoreDiv.textContent = `SEO Score: ${data.seoScore ?? 'N/A'}`;

            // Issues
            issuesUl.innerHTML = ''; // Clear previous
            if (data.issues && data.issues.length > 0) {
                 data.issues.forEach(issue => {
                    const li = document.createElement('li');
                    li.classList.add(`issue-${issue.type}`);
                    li.textContent = `${issue.message}`;
                    issuesUl.appendChild(li);
                });
                 issuesContainer.style.display = 'block';
            } else {
                 issuesUl.innerHTML = '<li>No issues found.</li>';
                 issuesContainer.style.display = 'block';
            }

            // Suggestions
            suggestionsUl.innerHTML = ''; // Clear previous
            if (data.suggestions && data.suggestions.length > 0) {
                 data.suggestions.forEach(suggestion => {
                    const li = document.createElement('li');
                    let contentHTML = `<strong>${suggestion.message}</strong><br/><em></em>`; // Use em for suggestion text
                     if (suggestion.context) {
                         contentHTML += `<br/><small>Context: ${suggestion.context.substring(0, 50)}...</small>`;
                     }
                     li.innerHTML = contentHTML;
                     li.querySelector('em').textContent = suggestion.content; // Set text safely

                     if (suggestion.type === 'ai_meta' || suggestion.type === 'ai_alt_text') {
                         const applyButton = createApplyButton(suggestion.content, suggestion.type, suggestion.context);
                         li.appendChild(applyButton);
                     }
                    suggestionsUl.appendChild(li);
                });
                 suggestionsContainer.style.display = 'block';
            } else {
                 suggestionsUl.innerHTML = '<li>No AI suggestions.</li>';
                 suggestionsContainer.style.display = 'block';
            }

            // Keyword Analysis
             keywordsDetailsDiv.innerHTML = ''; // Clear previous
             if (data.keywordAnalysis) {
                 const ka = data.keywordAnalysis;
                 keywordsDetailsDiv.innerHTML = `
                     <p><strong>Target: "${ka.targetKeyword}"</strong></p>
                     <ul style="list-style: none; padding-left: 0; margin-left: 0;">
                         <li>In Title: ${ka.foundInTitle ? '✅ Yes' : '❌ No'}</li>
                         <li>In Meta Desc: ${ka.foundInMeta ? '✅ Yes' : '❌ No'}</li>
                         <li>In H1: ${ka.foundInH1 ? '✅ Yes' : '❌ No'}</li>
                         <li>Body Count: ${ka.bodyCount}</li>
                         <li>Density: ${ka.density}%</li>
                     </ul>`;
                  keywordsContainer.style.display = 'block';
             } else {
                keywordsDetailsDiv.innerHTML = targetKeyword ? '<p>Keyword analysis not available.</p>' : '';
                keywordsContainer.style.display = targetKeyword ? 'block' : 'none';
             }

        })
        .catch(error => {
            console.error('Error calling AI SEO API:', error);
            statusP.textContent = `Error: ${error.message}`;
            // Clear results on error
            scoreDiv.innerHTML = '';
            issuesUl.innerHTML = '';
            suggestionsUl.innerHTML = '';
            keywordsDetailsDiv.innerHTML = '';
            issuesContainer.style.display = 'none';
            suggestionsContainer.style.display = 'none';
            keywordsContainer.style.display = 'none';
        })
        .finally(() => {
            analyzeButton.disabled = false;
        });
    });

    console.log("AI SEO Script Initialized"); // Add confirmation
});